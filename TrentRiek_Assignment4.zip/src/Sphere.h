#pragma once
#ifndef SPHERE
#define SPHERE
#include "Object.h"
#include <math.h>




#endif SPHERE