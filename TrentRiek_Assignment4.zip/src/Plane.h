#pragma once
#ifndef PLANE
#define PLANE
//#include "VectorMath.h"
//#include "GraphicsMath.h"
#include "Object.h"
#include <math.h>



#endif PLANE