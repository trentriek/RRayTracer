#include "Object.h"

Sphere::Sphere() :Object() {
	type = sphere;
}

Sphere::Sphere(vector3 Pos, float r) : Object(Pos) {
	type = sphere;
	radius = r;
}


Sphere::~Sphere() {

}

bool Sphere::hit(vector3 eye, vector3 Npe, vector3& HitPos, vector3& hitN) {

	//(pe - pi) dot(pe - pi) � r * r >= 0
	//b = npe dot (pi - pe)
	//	c = (pe - pi) dot (pe - pi) - r2
	//	tri = b2 - c = 0

	vector3 ei = (eye - pos);
	vector3 ie = (pos - eye);
	if (vector3::dot(ei, ei) >= 0.0f) {

		float b = vector3::dot(Npe, ie);
		float c = vector3::dot(ei, ei) - (radius * radius);
		float tri = (b * b) - c;
		if (b >= 0 && tri >= 0) {
			float th = b - sqrt(double(tri));
			HitPos = eye + (Npe * th);
			hitN = (HitPos - pos) / radius;
			//get normal

			return true;
		}


	}
	return false;
}


