#include "Object.h"

Plane::Plane() :Object() {
	type = sphere;
}

Plane::Plane(vector3 Pos, vector3 Normal) : Object(Pos) {
	type = sphere;
	Ni = Normal;
}

bool Plane::hit(vector3 eye, vector3 Npe, vector3& HitPos, vector3& HitN) {

	return false;
}

